<script type="text/x-template" id="app-footer-template">
  <footer class="app-footer py-2">
    <div class="container">
      <p class="mb-0">
        &copy; {{ new Date().getFullYear() }} BBVA, Todos los derechos reservados. | Desarrollado por CI&C - Relación con Supervisores v2
      </p>
    </div>
  </footer>
</script>

<script>
/* Client/js/components/AppFooter.vue.html */
const AppFooter = {
  template: '#app-footer-template',
};
</script>
